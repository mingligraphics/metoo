import * as d3 from 'd3'

const margin = {
  top: 10,
  right: 10,
  bottom: 10,
  left: 10
}

const width = 700 - margin.left - margin.right
const height = 400 - margin.top - margin.bottom
